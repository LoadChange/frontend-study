// conf/log.js
// Log配置
module.exports = {
	log: {
		logger_path: "./bin/logs/error.log",
		logger_level: 'debug' //debug | error
	}
};