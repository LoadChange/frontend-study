// conf/db.js
// MySQL数据库连接配置
module.exports = {
	mysql: {
		host: '127.0.0.1',
		port: 3306,
		database: 'mynews',
		user: 'root',
		password: 'root'
	}
};