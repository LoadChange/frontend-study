var manager = {
	
};

module.exports = manager;