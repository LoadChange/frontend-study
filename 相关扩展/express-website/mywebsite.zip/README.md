# bash shell cpu监控

安装 pm2:npm install -g pm2
./cpu-warning.sh
